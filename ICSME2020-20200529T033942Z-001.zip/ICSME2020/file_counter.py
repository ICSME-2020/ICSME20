import sys

from openpyxl import load_workbook


def file_counter(path):
    wb = load_workbook(path)
    worksheets = wb.worksheets
    for ws in worksheets:
        print(ws)
        for row in range(ws.max_row):
            if row == 0:
                ws.cell(row=row+1, column=8).value = 'No of files changed'
            else:
                changed_files = ws.cell(row=row + 1, column=4).value
                if changed_files:
                    ws.cell(row=row + 1, column=8).value = len(changed_files.split('\n'))
                else:
                    ws.cell(row=row + 1, column=8).value = 0
    wb.save(path)

if __name__ == '__main__':
    # initiate the work flow from here
    print('Processing....')
    args = sys.argv
    try:
        if len(args) == 2:
            file_counter(args[1])
        else:
            print("Invalid Arguments.")
    except Exception as e:
        print(f'Error occurred : {e}')
