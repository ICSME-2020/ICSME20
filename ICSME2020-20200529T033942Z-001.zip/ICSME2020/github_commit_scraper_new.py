import csv
import sys

from github import Github

repo_author = 'caffe2'



def write_to_csv(data):
    """
    Allows to write data in CSV format
    :param data:
    :return:
    """
    with open(f'{repo_name}_commit_data.csv', 'w', encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(
            ['Author', 'User', 'Project', 'Id of the first commit', 'Date of the first commit', 'Id of the last commit',
             'Date of the last commit', 'Number of total commit'])
        writer.writerows(data)
    file.close()
    return


def write_merge_to_csv(data):
    """
    Allows to write data in CSV format
    :param data:
    :return:
    """
    with open(f'{repo_name}_user_commit_merge_data.csv', 'w', encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(
            ['Author', 'User', 'Email', 'Location', 'Bio', 'Organizations', 'Project',
             'Id of the first commit', 'Date of the first commit', 'Id of the last commit',
             'Date of the last commit', 'Number of total commit'])
        writer.writerows(data)
    file.close()
    return


def get_commit_data(repo, username, author_name):
    """
    Get the commit data for a mentioned user against repo_name
    :param repo:
    :param username:
    :param author_name:
    :return:
    """
    temp_data = []
    first_commit = None
    last_commit = None
    commits = repo.get_commits(author=username)

    if commits.totalCount != 0:
        total_commit = commits.totalCount
        last_page = total_commit / 100
        if last_page.is_integer():
            last_page = int(last_page) - 1
        else:
            last_page = int(last_page)

        for commit in commits:
            last_commit = commit
            break

        for commit in reversed(commits.get_page(last_page)):
            first_commit = commit
            break

        temp_data.append(author_name)
        temp_data.append(username)
        temp_data.append(repo_name)
        temp_data.append(first_commit.sha)
        temp_data.append(first_commit.commit.author.date)
        temp_data.append(last_commit.sha)
        temp_data.append(last_commit.commit.author.date)
        temp_data.append(total_commit)
        return temp_data
    else:
        return []


def get_all_data(users_list):
    """
    Iterates each user to get commit data
    :return:
    """
    try:
        # initialized github with access token
        g = Github(login_or_token=GIT_ACCESS_KEY, per_page=100)
        commit_data = []
        merge_data = []
        r = g.get_repo(f"{repo_author}/{repo_name}")
        for user in users_list:

            if user['login']:
                username = user['login']
            else:
                username = user['author']

            author = user['author']

            print(f"Processing user {username}")

            try:
                # getting the repo using the username and repo_name
                data = get_commit_data(r, username, author)
                if data:
                    commit_data.append(data)
                    _new_list = list(user.values())
                    _new_list.extend(data[2:])
                    merge_data.append(_new_list)
                elif not user['login']:
                    # if no data found and try with author name
                    users = g.search_users(f"{user['author']} in:name")

                    if users.totalCount != 0:
                        for _user in users:
                            username = _user.login
                            # finding first user and exit the loop
                            break

                        data = get_commit_data(r, username, author)
                        if data:
                            commit_data.append(data)
                            _new_list = list(user.values())
                            _new_list.extend(data[2:])
                            merge_data.append(_new_list)
                    else:
                        _new_list = list(user.values())
                        merge_data.append(_new_list)
                        print(f"Repo {repo_name} not found for user '{username}'")
                else:
                    _new_list = list(user.values())
                    merge_data.append(_new_list)
                    print(f"Repo {repo_name} not found for user '{username}'")

            except Exception as e:
                _new_list = list(user.values())
                merge_data.append(_new_list)
                print(f"Repo {repo_name} not found for user '{username}'")

        write_to_csv(commit_data)

        write_merge_to_csv(merge_data)

        print(f'Successfully Completed: data found for {len(commit_data)} out of {len(users_list)}')
    except Exception as e:
        print(f'Something went Wrong: {e}')


if __name__ == '__main__':
    # initiate the work flow from here
    print('Processing....')
    args = sys.argv
    fields = ['author', 'login', 'email', 'loc', 'bio', 'organizations']
    users = []

    try:
        if len(args) == 2:
            with open(args[1], 'r', encoding="utf-8") as file:
                user_file = csv.reader(file, delimiter=';')
                next(user_file)
                for row in user_file:
                    author = row[0]
                    if '\\' in author:
                        author = author.split('\\')[1]
                    users.append({'author': author, 'login': row[1], 'email': row[2], 'loc': row[3].replace(',', '  '),
                                  'bio': row[4].replace(',', '  '), 'organizations': row[5].replace(',', '  ')})
            if len(users):
                get_all_data(users_list=users)
            else:
                print("No users fount in the given file")
        else:
            print("Invalid Arguments.")
    except Exception as e:
        print(f'Error occurred : {e}')
