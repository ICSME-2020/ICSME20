import csv

from github import Github
from openpyxl import Workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from time import sleep, time
from datetime import datetime, timedelta

user_name = 'tensorflow'
repo_name = 'tensorflow'
# Enter below the username of the account that the GIT_ACCESS_KEY token belongs to


account_username = ''
GIT_ACCESS_KEY = ''
# When the number of remaining calls is less than or equal to this number,
# the script will pause and wait until it is safe to continue executing.
# The information about when it paused and when it will continue will be printed out in the terminal
pause_number = 50

# initialized github with access token
# Using username and token will make you authenticated user.
# Use if 60 calls/h is too little for your use.
# Max calls using this method of authentication: 5000/h;
g = Github(account_username, GIT_ACCESS_KEY, per_page=100, timeout=100)


# Using only token will make you unauthenticated user.
# Max calls using this method of authentication: 5000;
# To use uncomment line below and comment the line above starting with g = ...
# g = Github(login_or_token=GIT_ACCESS_KEY, per_page=30)

def check_remaining_calls():
    """
    This function checks the remaining number of calls and pauses if the number of remaining calls is less than pause_number.
    """

    current_time = datetime.now()

    # Add a number of seconds to reset time just to be safe
    reset_time = datetime.fromtimestamp(g.rate_limiting_resettime) + timedelta(seconds=10)

    restart_time = reset_time - current_time

    if g.get_rate_limit().core.remaining <= pause_number:

        print(
            f'Rate limit exceeded, pausing script for {restart_time}\nPaused at {current_time} \nContinuing at {reset_time}')

        sleep(restart_time.total_seconds())

    else:
        pass


def write_issues_to_xls(data):
    """
    Allows to write issues data in XLS format
    :param data:
    :param ext_list:
    :return:
    """
    wb = Workbook()

    # set file path
    filepath = f'{repo_name}_issues.xls'
    sheet = wb.active
    header = ['project', 'issue number', 'issue title', 'issue label', 'issue author', 'issue status']
    sheet.append(header)
    for row in data:
        sheet.append(row)
    # save file
    wb.save(filepath)
    return


def get_issues_data():
    r = g.get_repo(f"{user_name}/{repo_name}")
    issue_data = []
    _ = lambda x: ILLEGAL_CHARACTERS_RE.sub('', x)
    for issue in r.get_issues(state='all'):
        try:
            check_remaining_calls()
            print(f'fetching for issue: {issue.number}')
            labels = ','.join(label.name for label in issue.labels)
            issue_data.append([repo_name, issue.number, _(issue.title), _(labels), _(issue.user.login), issue.state])
        except Exception as e:
            print(e)
    write_issues_to_xls(issue_data)
    print('Completed')


if __name__ == '__main__':
    # initiate the work flow from here
    print('Processing....')
    get_issues_data()
