import pandas as pd
import numpy as np

FILE_NAME = 'torch7_pull_request_commit_modified.xlsx'
BUG_WORDS = ["fix", "bug", "error", "issue", "mistake", "blunder", "incorrect", "fault", "defect", "flaw", "bugfix",
             "bugfix:"]

file_df = pd.read_excel(FILE_NAME)
is_bug = []

print("Processing")
for index, row in file_df.iterrows():
    bug = 0
    message = row['Pull request message']
    if message and message is not np.nan:
        for word in BUG_WORDS:
            if word in message:
                bug = 1
    is_bug.append(bug)
file_df['is_bug'] = is_bug

file_df.to_excel(FILE_NAME.split('.')[0] + '_bug_count_added.xlsx', index=False)
print("Completed !!")
