import sys
from datetime import datetime, timedelta
from time import sleep

from github import Github
from openpyxl import Workbook, load_workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

user_name = 'PaddlePaddle'
repo_name = 'Paddle'
# Enter below the username of the account that the GIT_ACCESS_KEY token belongs to

account_username = ''
GIT_ACCESS_KEY = ''
BATCH_SIZE = 100
# When the number of remaining calls is less than or equal to this number,
# the script will pause and wait until it is safe to continue executing.
# The information about when it paused and when it will continue will be printed out in the terminal
pause_number = 50

# initialized github with access token
# Using username and token will make you authenticated user.
# Use if 60 calls/h is too little for your use.
# Max calls using this method of authentication: 5000/h;
g = Github(account_username, GIT_ACCESS_KEY, per_page=100, timeout=5000)

# Using only token will make you unauthenticated user.
# Max calls using this method of authentication: 5000;
# To use uncomment line below and comment the line above starting with g = ...
# g = Github(login_or_token=GIT_ACCESS_KEY, per_page=30)

def write_to_xls(data):
    # set file path
    name = repo_name.replace('-', '_')
    filepath = f'{name}_pull_request_commit.xlsx'

    try:
        _header = False
        wb = load_workbook(filepath)
    except:
        _header = True
        wb = Workbook()
    sheet = wb.active
    if _header:
        sheet.append(
            ['Project', 'id of the pull request', 'User of the pull request', 'State of the pull request', 'Merged',
             'Open/Accept/Reject',
             'Pull request message', 'Pull request label', 'SHA commit', 'Commit message', 'User of the commit',
             'Author_Date', 'insertion',
             'deletion', 'Number of changed files per commit', 'Number of commit per pull request'])
    for key, values in data.items():
        for row in values:
            try:
                sheet.append(row)
            except Exception as e:
                print(f'Error: {e}')
    # save file
    wb.save(filepath)


def write_commit_to_xls(data, ext_list):
    """
    Allows to write commit data in XLS format
    :param data:
    :param ext_list:
    :param _header
    :return:
    """
    name = repo_name.replace('-', '_')
    # set file path
    filepath = f'{name}_pull_request_commit_files.xlsx'

    try:
        wb = load_workbook(filepath)
        _header = False
    except Exception as e:
        _header = True
        wb = Workbook()

    sheet = wb.active
    if _header:
        header = ['project', 'sha', 'file_name', 'Co-change', 'Mono/Multi', 'inserted', 'deleted']
        if 'others' not in ext_list:
            ext_list.append('others')
        for ext in ext_list:
            header.append(ext)
            header.append('%')

        sheet.append(header)

    for row in data:
        try:
            if row[0] and row[2]:
                ext = row[-2]
                attach_row = row[:-2]
                for _header_ext in ext_list:
                    if _header_ext in ext:
                        attach_row.append(ext[_header_ext])
                        attach_row.append((ext[_header_ext] / row[-1]) * 100)
                    else:
                        attach_row.append(None)
                        attach_row.append(None)
                sheet.append(attach_row)
            else:
                sheet.append(row)
        except Exception as e:
            print(f'Error: {e}')

    # save file
    wb.save(filepath)
    return


def check_remaining_calls(wait=False):
    """
    This function checks the remaining number of calls and pauses if the number of remaining calls is less than pause_number.
    :rtype: object
    """

    current_time = datetime.now()

    # Add a number of seconds to reset time just to be safe
    reset_time = datetime.fromtimestamp(g.rate_limiting_resettime) + timedelta(seconds=10)

    restart_time = reset_time - current_time
    t = g.get_rate_limit().core.remaining
    if wait:
        print(
            f'Rate limit exceeded, pausing script for {restart_time}\nPaused at {current_time} \nContinuing at {reset_time}')

        sleep(restart_time.total_seconds())
        return t

    if t <= pause_number:

        print(
            f'Rate limit exceeded, pausing script for {restart_time}\nPaused at {current_time} \nContinuing at {reset_time}')

        sleep(restart_time.total_seconds())
        return t
    else:
        return t


def get_pull_request_data(skip):
    """
    Get all the pull requests for a mentioned repo
    :return:
    """
    try:
        print(f"Batch Size is configured as {BATCH_SIZE}. For every {BATCH_SIZE} pulls, data will be append on file")

        # categorized based on pull request acceptance status
        pull_request_data = {
            'accepted': [],
            'open': [],
            'rejected': []
        }
        commit_file_data = []
        # Check number of remaining API calls before the first call is made
        remaining = check_remaining_calls()

        # getting the repo using the username and repo_name
        r = g.get_repo(f"{user_name}/{repo_name}")
        EXT_LIST = []
        ext_scraper = lambda x: 'others' if '.' not in x else x.rsplit('.', 1)[1]
        _ = lambda x: ILLEGAL_CHARACTERS_RE.sub('', x)

        pull_list = []
        pulls = r.get_pulls(state='all')
        total_pull_count = pulls.totalCount

        if int(total_pull_count / 100) + 1 > remaining:
            check_remaining_calls(wait=True)

        print('Initial Pull Fetch started')
        for i, pull in enumerate(pulls):
            check_remaining_calls()
            # skips already collected pages
            if i < skip:
                continue
            # Skips already collected pulls in current page
            else:
                print(pull.number)
                pull_list.append([pull, repo_name, pull.number, _(pull.user.login),
                                  pull.state, True if pull.merged_at else False,
                                  _(pull.title),
                                  ', '.join([_(label.name) for label in pull.labels]),
                                  True if pull.closed_at else False])

        print(f'It seems totally {total_pull_count} pull requests')
        if skip:
            print(f'Skips {skip} out of {total_pull_count}. Starting from {skip + 1} pulls')

        print(f'Started fetching commits of pull requests')
        pull_count = 0
        for _meta in pull_list:
            pull_count += 1
            pull = _meta[0]
            print(f'Working on pull request {pull.number}')
            temp = _meta[1:8]

            commit_data = []
            try:
                commits = pull.get_commits()
                commit_count = commits.totalCount
                remaining = check_remaining_calls()
                if commit_count + 1 > remaining:
                    check_remaining_calls(wait=True)

                for commit in commits:
                    check_remaining_calls()
                    _commit_temp = [commit.sha, _(commit.commit.message), _(commit.commit.author.name),
                                    commit.commit.author.date]
                    insertion_count = 0
                    deletion_count = 0
                    file_data = []
                    for file in commit.files:
                        insertion_count += file.additions
                        deletion_count += file.deletions
                        file_data.append([file.filename, file.additions, file.deletions])

                    _commit_temp.append(insertion_count)
                    _commit_temp.append(deletion_count)
                    _commit_temp.append(len(file_data))
                    commit_data.append(_commit_temp)
                    if file_data:
                        ext_data = {}
                        _first_file_data = [repo_name, commit.sha, file_data[0][0],
                                            True if len(file_data) > 1 else False, file_data[0][1], file_data[0][2]]
                        _other_file_data = []
                        x = ext_scraper(file_data[0][0])
                        if x not in EXT_LIST:
                            EXT_LIST.append(x)
                        if x not in ext_data:
                            ext_data[x] = 0
                        ext_data[x] = ext_data.get(x, 0) + 1
                        if len(file_data) > 1:
                            for f in file_data[1:]:
                                _other_file_data.append([None, None, f[0], None, None, f[1], f[2]])
                                x = ext_scraper(f[0])
                                if x not in EXT_LIST:
                                    EXT_LIST.append(x)
                                ext_data[x] = ext_data.get(x, 0) + 1

                        if len(ext_data.keys()) > 1:
                            _first_file_data.insert(4, 'Multi')
                        else:
                            _first_file_data.insert(4, 'Mono')
                        _first_file_data.append(ext_data)
                        _first_file_data.append(len(file_data))
                        commit_file_data.append(_first_file_data)
                        if _other_file_data:
                            commit_file_data.extend(_other_file_data)
                    else:
                        commit_file_data.append([repo_name, commit.sha, None])

            except Exception as e:
                print(e)
                print(
                    f'Can\'t get files in pull number {pull.number}. Continuing.')
                continue

            if commit_data:
                temp.extend(commit_data[0])
            else:
                t = [None for i in range(8)]
                temp.extend(t)

            temp.append(commit_count)
            # if it is merged and closed then it is accepted
            if _meta[5] and _meta[8]:
                temp.insert(5, 'Accepted')
                pull_request_data['accepted'].append(temp)
                if len(commit_data) > 1:
                    for _commit_data in commit_data[1:]:
                        _temp = [None for i in range(8)]
                        _temp.extend(_commit_data)
                        _temp.append(None)
                        pull_request_data['accepted'].append(_temp)

            # if it is not merged but closed then it is rejected
            elif not _meta[5] and _meta[8]:
                temp.insert(5, 'Rejected')
                pull_request_data['rejected'].append(temp)
                if len(commit_data) > 1:
                    for _commit_data in commit_data[1:]:
                        t = [None for i in range(8)]
                        t.extend(_commit_data)
                        t.append(None)
                        pull_request_data['rejected'].append(t)

            # if it is not merged and not closed then it is in open state
            else:
                temp.insert(5, 'Open')
                pull_request_data['open'].append(temp)
                if len(commit_data) > 1:
                    for _commit_data in commit_data[1:]:
                        t = [None for i in range(8)]
                        t.extend(_commit_data)
                        t.append(None)
                        pull_request_data['open'].append(t)

            if (pull_count % BATCH_SIZE) == 0:
                print(f'Writing data from {skip + pull_count - BATCH_SIZE} to {skip + pull_count}')

                write_to_xls(pull_request_data)
                write_commit_to_xls(commit_file_data, EXT_LIST)
                pull_request_data = {
                    'accepted': [],
                    'open': [],
                    'rejected': []
                }
                commit_file_data = []

        write_to_xls(pull_request_data)
        write_commit_to_xls(commit_file_data, EXT_LIST)
        print('Successfully Completed all pull requests')


    except Exception as e:

        # print(f'Something went Wrong: {e}')
        print(e)


if __name__ == '__main__':
    # initiate the work flow from here
    print('Processing....')
    args = sys.argv
    try:
        if len(args) > 1:
            skip = int(args[1])
            print(f"Trying to skip {skip} pulls")
        else:
            skip = 200
            print(f"No Skip provided Starting from initial. Please delete the file, if already exists")
    except Exception as e:
        print(e)
        print('Issue in Skip value. Skip must be a integer')
    else:
        try:
            get_pull_request_data(skip=skip)
        except Exception as e:
            print(f"unknown error happend: {e}")
