import sys

import xlrd
from openpyxl.workbook import Workbook


def cvt_xls_to_xlsx(src_file_path):
    book_xls = xlrd.open_workbook(src_file_path)
    book_xlsx = Workbook()

    sheet_names = book_xls.sheet_names()
    for sheet_index in range(0, len(sheet_names)):
        sheet_xls = book_xls.sheet_by_name(sheet_names[sheet_index])
        if sheet_index == 0:
            sheet_xlsx = book_xlsx.active
            sheet_xlsx.title = sheet_names[sheet_index]
        else:
            sheet_xlsx = book_xlsx.create_sheet(title=sheet_names[sheet_index])

        for row in range(0, sheet_xls.nrows):
            for col in range(0, sheet_xls.ncols):
                sheet_xlsx.cell(row=row + 1, column=col + 1).value = sheet_xls.cell_value(row, col)

    book_xlsx.save(f'{src_file_path}x')
    print("Completed")

if __name__ == '__main__':
    # initiate the work flow from here
    args = sys.argv
    try:
        if len(args) == 2:
            print("Processing .......")
            cvt_xls_to_xlsx(args[1])
        else:
            print("Invalid Arguments.")
    except Exception as e:
        print(e)
