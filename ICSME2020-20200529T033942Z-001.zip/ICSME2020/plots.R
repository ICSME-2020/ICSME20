library(reshape2)
library(gridExtra)
library(ggpubr)
andata<-read.table("t1.txt", sep="\t", ,header=T, check.names = FALSE)
pellets<-c("#fe4a49",  "cyan", "#2ab7ca", "#fed766" , "#e6e6ea" , "#f4f4f8", "#4a4e4d" ,"#0e9aa7" , "pink", "#f6cd61", "#fe8a71")
n<-andata[c(1,2,3)]
m<-melt(n, id.vars = "Systems")
p1<-ggboxplot(m , x="variable", y="value", color="variable", palette=pellets[1:2])

n<-andata[c(1,5,6,7)]
m<-melt(n, id.vars = "Systems")
p2<-ggboxplot(m , x="variable", y="value", color="variable", , palette=pellets[1:3])

grid.arrange(p1, p2, ncol = 1)

andata<-read.table("t2.txt", sep="\t", ,header=T, check.names = FALSE)
andata$S<-1:10

n<-andata[c(1,3, 7)]
m<-melt(n, id.vars = "S")
p3<-ggboxplot(m , x="variable", y="value", color="variable", palette=pellets[1:2])

n<-andata[c(2,4,6,7)]
m<-melt(n, id.vars = "S")
p4<-ggboxplot(m , x="variable", y="value", color="variable", , palette=pellets[1:3])

grid.arrange(p3, p4, ncol = 1)
