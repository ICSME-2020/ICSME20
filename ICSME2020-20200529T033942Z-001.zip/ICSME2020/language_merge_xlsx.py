import sys

from openpyxl import Workbook, load_workbook


def write_issues_to_xls(data):
    """
    Allows to write issues data in XLS format
    :param data:
    :param ext_list:
    :return:
    """
    wb = Workbook(write_only=True)

    # set file path
    filepath = f'{repo_name}_merged_pull_data.xls'
    sheet = wb.create_sheet(title='data', index=0)
    for row in data:
        sheet.append(row)
    wb.save(filepath)
    return


def language_merger(file1, file2):
    SHA_DICT = {}
    PULL_DICT = {}

    # sheet 2
    wb = load_workbook(file2, read_only=True)
    worksheet = wb.active

    for row in worksheet.rows:
        sha = row[1].value
        if sha:
            SHA_DICT[sha] = row[4].value

    # sheet 1
    wb = load_workbook(file1, read_only=True)
    worksheet = wb.active
    for i, row in enumerate(worksheet.rows):
        if i != 0:
            pull = row[1].value
            if pull:
                last_pull = int(pull)
                PULL_DICT[last_pull] = [row[8].value]
            else:
                PULL_DICT[last_pull].append(row[8].value)

    wb = load_workbook(file1, read_only=True)
    worksheet = wb.active
    merged_data = []
    for i, row in enumerate(worksheet.rows):
        if i == 0:
            header = [x.value for x in row]
            header.append('mono/multi')
            header.append('mono-multi')
            merged_data.append(header)
        else:
            new_row = [x.value for x in row]
            pull = row[1].value
            if pull:
                pull = int(pull)
                commits = PULL_DICT[pull]
                tot_commits = len(commits)
                mono = 0
                multi = 0
                has_commit = False
                for commit in commits:
                    if commit:
                        has_commit = True
                        if SHA_DICT[commit] == 'Mono':
                            mono += 1
                        else:
                            multi += 1
                if has_commit:
                    if multi > 0:
                        value2 = 'Multi'
                        if (multi / tot_commits) > 0.5:
                            value1 = 'Multi'
                        else:
                            value1 = 'Mono'
                    else:
                        value1 = 'Mono'
                        value2 = 'Mono'
                else:
                    value1 = None
                    value2 = None
                new_row.append(value1)
                new_row.append(value2)
                merged_data.append(new_row)
            else:
                new_row.append(None)
                new_row.append(None)
                merged_data.append(new_row)

    print(len(merged_data))
    write_issues_to_xls(merged_data)
    print("Successfully created...")


if __name__ == '__main__':
    # initiate the work flow from here
    args = sys.argv
    try:
        if len(args) == 4:
            repo_name = args[1]
            print("Processing...")
            language_merger(args[2], args[3])
        else:
            print("Invalid Arguments.")
    except Exception as e:
        print(f'Error occurred : {e}')