import csv
import sys
import datetime
from csv import DictWriter, DictReader
from github import Github
from openpyxl import Workbook


repo_name = 'Paddle'




def write_to_xls(data):
    wb = Workbook()

    filepath = f'{repo_name}_commit_data.xls'
    sheet = wb.active
    sheet.append(
        ['Users', 'Project', 'Id of the first commit', 'Date of the first commit', 'Id of the last commit',
         'Date of the last commit', 'Number of total commit'])
    for row in data:
        sheet.append(row)
    # save file
    wb.save(filepath)


def get_commit_data(users_list):
    """
    Get the commit data for a mentioned repo, user
    :return:
    """
    try:
        # initialized github with access token
        g = Github(login_or_token=GIT_ACCESS_KEY, per_page=100)
        commit_data = []
        for username in users_list:
            print(f"Processing user {username}")
            try:
                # getting the repo using the username and repo_name
                r = g.get_repo(f"{username}/{repo_name}")
                temp_data = []
                first_commit = None
                total_commit = 0
                last_commit = None

                temp_data.append(username)
                temp_data.append(repo_name)

                for commit in r.get_commits(author=username):
                    total_commit += 1
                    if total_commit == 1:
                        first_commit = commit
                    last_commit = commit

                temp_data.append(first_commit.sha)
                temp_data.append(first_commit.commit.author.date)
                temp_data.append(last_commit.sha)
                temp_data.append(last_commit.commit.author.date)
                temp_data.append(total_commit)
                commit_data.append(temp_data)

            except Exception as e:
                print(f"Repo {repo_name} not found for user '{username}'")

        write_to_xls(commit_data)

        print('Successfully Completed')
    except Exception as e:
        print(f'Something went Wrong: {e}')


if __name__ == '__main__':
    # initiate the work flow from here
    print('Processing....')
    args = sys.argv
    fields = ['author', 'login', 'email', 'loc', 'bio', 'organizations']
    users = []

    try:
        if len(args) == 2:
            # print(f'Fetching data for {args[1]}, {args[2]}')
            with open(args[1], 'r', encoding="utf8") as file:
                reader = DictReader(file, fieldnames=fields)
                next(reader)
                for row in reader:
                    if row['login']:
                        users.append(row['login'])
            if len(users):
                get_commit_data(users_list=users)
            else:
                print("No users found in the given file")
        else:
            print("Invalid Arguments.\n using the default data in file")
    except Exception as e:
        print(f'Error occured : {e}')
