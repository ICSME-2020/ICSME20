import sys
from datetime import datetime, timedelta
from time import sleep

import pandas as pd
from github import Github

user_name = 'keras-team'
repo_name = 'keras'

account_username = ''
GIT_ACCESS_KEY = ''

# When the number of remaining calls is less than or equal to this number,
# the script will pause and wait until it is safe to continue executing.
# The information about when it paused and when it will continue will be printed out in the terminal
pause_number = 50

# initialized github with access token
# Using username and token will make you authenticated user.
# Use if 60 calls/h is too little for your use.
# Max calls using this method of authentication: 5000/h;
g = Github(account_username, GIT_ACCESS_KEY, per_page=100, timeout=100)


# Using only token will make you unauthenticated user.
# Max calls using this method of authentication: 5000;
# To use uncomment line below and comment the line above starting with g = ...
# g = Github(login_or_token=GIT_ACCESS_KEY, per_page=30)

def check_remaining_calls():
    """
    This function checks the remaining number of calls and pauses if the number of remaining calls is less than pause_number.
    """

    current_time = datetime.now()

    # Add a number of seconds to reset time just to be safe
    reset_time = datetime.fromtimestamp(g.rate_limiting_resettime) + timedelta(seconds=10)

    restart_time = reset_time - current_time

    if g.get_rate_limit().core.remaining <= pause_number:

        print(
            f'Rate limit exceeded, pausing script for {restart_time}\nPaused at {current_time} \nContinuing at {reset_time}')

        sleep(restart_time.total_seconds())

    else:
        pass


def modify_pull_requests(path):
    r = g.get_repo(f"{user_name}/{repo_name}")
    df = pd.read_excel(path, na_filter=False, index_col=[0])
    time_period = []
    file_changed_per_pull = []
    files_changed = 0
    user_list_per_commit = set()
    commits = 0
    users = []
    skip = False
    for index, row in df.iterrows():
        if row['id of the pull request']:
            check_remaining_calls()
            try:
                pull = r.get_pull(row['id of the pull request'])
                skip = False
            except Exception as e:
                print(e)
                print("Skipping Pull Request : {}".format(row['id of the pull request']))
                skip = True

            print("Processing pull: {}".format(row['id of the pull request']))

            if not skip and pull.closed_at and pull.created_at:
                difference = int((pull.closed_at - pull.created_at).total_seconds() // 60)
            else:
                difference = None
            time_period.append(difference)
            file_changed_per_pull.append(files_changed)
            users.append(len(user_list_per_commit))
            files_changed = 0
            user_list_per_commit = set()
            for commit in range(commits):
                file_changed_per_pull.append(None)
                users.append(None)

            commits = 0

        else:
            commits += 1
            time_period.append(None)
        if not skip:
            if row['Number of changed files per commit']:
                files_changed += row['Number of changed files per commit']
            if row['User of the commit']:
                user_list_per_commit.add(row['User of the commit'])

    file_changed_per_pull.append(files_changed)
    users.append(len(user_list_per_commit))
    for commit in range(commits):
        file_changed_per_pull.append(None)
        users.append(None)
    kwargs = {"Files changes per pull request": file_changed_per_pull[1:],
              "Participants implicated in pull request": users[1:],
              "time spent": time_period}
    df2 = df.assign(**kwargs)
    df2.to_excel(path.split('.xlsx')[0] + '_modified.xlsx', index=False)


if __name__ == '__main__':
    # initiate the work flow from here
    print('Processing....')
    args = sys.argv
    try:
        if len(args) == 2:
            modify_pull_requests(args[1])
        else:
            print("Invalid Arguments.")
    except Exception as e:
        print(f'Error occurred : {e}')
